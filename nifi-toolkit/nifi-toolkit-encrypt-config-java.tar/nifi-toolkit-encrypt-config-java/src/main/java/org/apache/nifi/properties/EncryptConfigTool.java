package org.apache.nifi.properties;

import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class EncryptConfigTool {
    private static final Logger logger = LoggerFactory.getLogger(EncryptConfigTool.class);

    private static final String HELP_ARG = "help";
    private static final String VERBOSE_ARG = "verbose";
    //    private static final String BOOTSTRAP_CONF_ARG = "bootstrapConf";
    private static final String NIFI_PROPERTIES_ARG = "niFiProperties";

    // Static holder to avoid re-generating the options object multiple times in an invocation
    private static Options staticOptions;

    static Options buildOptions() {
        Options options = new Options();
        options.addOption(Option.builder("h").longOpt(HELP_ARG).hasArg(false).desc("Show usage information (this message)").build());
        options.addOption(Option.builder("v").longOpt(VERBOSE_ARG).hasArg(false).desc("Sets verbose mode (default false)").build());
        options.addOption(Option.builder("n").longOpt(NIFI_PROPERTIES_ARG).hasArg(true).argName("file").desc("The nifi.properties file containing unprotected config values (will be overwritten unless -o is specified)").build());
        // TODO: add more options
        return options;
    }

    static Options getCliOptions() {
        // TODO: keep this in an 'if', or simply define the static options in a static{} block?
        if (staticOptions.getOptions().isEmpty()) {
            staticOptions = buildOptions();
        }
        return staticOptions;
    }
}
