package org.apache.nifi.toolkit.encryptconfig;

import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.nifi.properties.EncryptConfigTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EncryptConfigMain {

    private static final Logger logger = LoggerFactory.getLogger(EncryptConfigMain.class);

    static final int EXIT_STATUS_SUCCESS = 0;
    static final int EXIT_STATUS_FAILURE = -1;
    static final int EXIT_STATUS_OTHER = 1;

    static final String NIFI_REGISTRY_OPT = "nifiRegistry";
    static final String NIFI_REGISTRY_FLAG = "--" + NIFI_REGISTRY_OPT;
    static final String DECRYPT_OPT = "decrypt";
    static final String DECRYPT_FLAG = "--" + DECRYPT_OPT;

    static final int HELP_FORMAT_WIDTH = 160;


    static void printUsage(String message) {
        if (message != null) {
            System.out.println(message);
            System.out.println();
        }

        System.out.println("  ---   Detailed usage goes here   ---");
        System.out.println();

        String header = "\nThis tool enables easy encryption and decryption of configuration files for NiFi and its sub-projects. "
                + "Unprotected files can be input to this tool to be protected by a key in a manner that is understood by NiFi. "
                + "Protected files, along with a key, can be input to this tool to be unprotected, for troubleshooting or automation purposes.\n\n";

        Options options = new Options();
        options.addOption("h", "help", false, "Show usage information (this message)");
        options.addOption(null, NIFI_REGISTRY_OPT, false, "Specifies to target NiFi Registry. When this flag is not included, NiFi is the target.");

        HelpFormatter helpFormatter = new HelpFormatter();
        helpFormatter.setWidth(160);
        helpFormatter.setOptionComparator(null);
        helpFormatter.printHelp(EncryptConfigMain.class.getCanonicalName() + " [-h] [options]", header, options, "\n");
        System.out.println();

        helpFormatter.setSyntaxPrefix(""); // disable "usage: " prefix for the following outputs

        // TODO: update to java version of ConfigEncryptTool
        Options nifiModeOptions = EncryptConfigTool.getCliOptions(); //ConfigEncryptionTool.getCliOptions();
        nifiModeOptions.addOption(null, DECRYPT_OPT, false, "TODO: add decrypt option for NiFi mode similar to NiFi Registry mode");
        helpFormatter.printHelp(
                "When targeting NiFi:",
                nifiModeOptions,
                false);
        System.out.println();

        // TODO: update to java version of NiFiRegistryMode
//        Options nifiRegistryModeOptions = NiFiRegistryMode.getCliOptions();
//        nifiRegistryModeOptions.addOption(null, DECRYPT_OPT, false, "Can be used with -r to decrypt a previously encrypted NiFi Registry Properties file. Decrypted content is printed to STDOUT.");
//        helpFormatter.printHelp(
//                "When targeting NiFi Registry using the ${NIFI_REGISTRY_FLAG} flag:",
//                nifiRegistryModeOptions,
//                false);
//        System.out.println();
    }

    static void printUsageAndExit(int exitStatusCode) {
        printUsage("no message here");
        System.exit(exitStatusCode);
    }

    static void printUsageAndExit(String message, int exitStatusCode) {
        printUsage(message);
        System.exit(exitStatusCode);
    }

    public static void main(String[] args) {
        // START DEBUG
        System.out.println("Starting EncryptConfigMain");
        int num=0;
        for (String arg : args) {
            System.out.println("argument[" + num + "] = " +arg);
        }
        // END DEBUG

        if (args.length < 1) {
            printUsageAndExit(EXIT_STATUS_FAILURE);
        }

    }
}
